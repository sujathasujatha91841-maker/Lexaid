import React from 'react'
import ReactDOM from 'react-dom/client'
import LexAid from './LexAid.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <LexAid />
  </React.StrictMode>,
)
