import React, { useState, useRef } from 'react';
import { Camera, Upload, AlertCircle, CheckCircle2, Clock, DollarSign, FileText, ChevronRight, ChevronLeft, Loader2, X, Send, MessageCircle, Car, Home, Briefcase, ShoppingBag, FileSignature, Scale, ArrowLeft, FileStack, Trash2, Download } from 'lucide-react';

const TOPICS = {
  traffic: {
    label: "Traffic Ticket",
    icon: Car,
    blurb: "Speeding, red lights, parking, e-challans",
    intakeMode: "photo",
    countries: {
      US: {
        label: "United States", currency: "USD", symbol: "$",
        notes: "Fines vary by state and county. Figures shown are typical ranges.",
        violations: {
          speeding: { name: "Speeding", fineRange: [50, 500], points: "2–6 points depending on speed over limit", contestable: true, howToContest: "Request a court date on the ticket, or mail a 'not guilty' plea before the deadline. Many states allow online traffic school to dismiss points for a fee instead of contesting.", deadline: "Typically 30 days from issue date", impact: "Often raises insurance premiums 20–30% for 3 years if points are assessed" },
          red_light: { name: "Red light / Signal violation", fineRange: [100, 500], points: "2–4 points (camera tickets often carry no points)", contestable: true, howToContest: "Camera-issued tickets can often be contested by mail arguing driver identity or signal timing.", deadline: "Typically 30 days", impact: "Camera tickets with no points usually don't affect insurance" },
          parking: { name: "Parking violation", fineRange: [25, 150], points: "Usually no points", contestable: true, howToContest: "Most cities allow online or mail-in contest with photo evidence within 14–21 days", deadline: "Typically 14–21 days", impact: "None — doesn't affect insurance or license points" },
          no_insurance: { name: "Driving without insurance", fineRange: [150, 1000], points: "Possible license suspension in some states", contestable: true, howToContest: "Provide proof of valid insurance at time of stop to the court", deadline: "Typically 30 days", impact: "Severe — may require SR-22 filing for 3 years" }
        }
      },
      IN: {
        label: "India", currency: "INR", symbol: "₹",
        notes: "Fines set under Motor Vehicles (Amendment) Act, 2019. States may apply modified amounts.",
        violations: {
          speeding: { name: "Overspeeding", fineRange: [1000, 2000], points: "License may be suspended for repeat offenses", contestable: true, howToContest: "Pay online via Parivahan portal or contest in local traffic court within the response window", deadline: "60 days (varies by state)", impact: "Not directly linked to insurance currently" },
          no_helmet: { name: "Riding without helmet", fineRange: [1000, 1000], points: "3-month license disqualification possible", contestable: false, howToContest: "Generally not contestable — pay via Parivahan e-challan portal", deadline: "60 days", impact: "None directly" },
          no_seatbelt: { name: "Not wearing seatbelt", fineRange: [1000, 1000], points: "None typically", contestable: false, howToContest: "Pay via Parivahan e-challan portal", deadline: "60 days", impact: "None" },
          red_light: { name: "Signal jumping", fineRange: [1000, 5000], points: "Possible license action for repeat offenses", contestable: true, howToContest: "File objection via Parivahan portal or local traffic court", deadline: "60 days", impact: "Not directly linked currently" },
          no_license: { name: "Driving without valid license", fineRange: [5000, 5000], points: "Possible vehicle impoundment", contestable: true, howToContest: "Show valid license at designated traffic office to get fine reduced or dismissed", deadline: "60 days", impact: "Invalidates insurance claims in event of accident" }
        }
      },
      UK: {
        label: "United Kingdom", currency: "GBP", symbol: "£",
        notes: "Fixed Penalty Notice amounts are generally standardized nationally.",
        violations: {
          speeding: { name: "Speeding", fineRange: [100, 100], points: "3 points (or speed awareness course if eligible)", contestable: true, howToContest: "Request a court hearing if you believe the notice is incorrect, or accept the fixed penalty within 28 days.", deadline: "28 days to respond", impact: "Points stay on license 4 years and typically raise premiums" },
          red_light: { name: "Red light violation", fineRange: [100, 100], points: "3 points", contestable: true, howToContest: "Respond to the Notice of Intended Prosecution within 28 days", deadline: "28 days", impact: "Raises premiums while points remain on license" },
          parking: { name: "Parking Penalty Charge Notice", fineRange: [25, 130], points: "None", contestable: true, howToContest: "Submit a formal challenge to the council within 14 days for a reduced rate", deadline: "14–28 days", impact: "None" },
          no_insurance: { name: "No insurance", fineRange: [300, 300], points: "6 points, possible vehicle seizure", contestable: true, howToContest: "Provide a valid insurance certificate to police within 7 days if it existed at time of stop", deadline: "7–28 days", impact: "Severe — future premiums rise substantially" }
        }
      }
    }
  },
  tenant: {
    label: "Tenant & Housing",
    icon: Home,
    blurb: "Eviction notices, deposits, repairs, lease disputes",
    intakeMode: "describe"
  },
  employment: {
    label: "Workplace",
    icon: Briefcase,
    blurb: "Termination, unpaid wages, discrimination, contracts",
    intakeMode: "describe"
  },
  consumer: {
    label: "Consumer Dispute",
    icon: ShoppingBag,
    blurb: "Refunds, faulty goods, scams, billing disputes",
    intakeMode: "describe"
  },
  contract: {
    label: "Contract Review",
    icon: FileSignature,
    blurb: "Upload documents for clause-by-clause analysis & memo",
    intakeMode: "document_review"
  },
  other: {
    label: "Something Else",
    icon: Scale,
    blurb: "Any other everyday legal question",
    intakeMode: "describe"
  }
};

const STAGES = { TOPIC_SELECT: 'topic', INTAKE: 'intake', PROCESSING: 'processing', RESULT: 'result', MEMO: 'memo', ERROR: 'error' };
const LANGUAGES = ['English', 'Spanish', 'Hindi', 'French', 'Arabic', 'Mandarin Chinese', 'Portuguese', 'Bengali', 'Urdu', 'German', 'Japanese', 'Tagalog'];

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function LexAid() {
  const [stage, setStage] = useState(STAGES.TOPIC_SELECT);
  const [topic, setTopic] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [briefing, setBriefing] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');
  const fileInputRef = useRef(null);

  const reset = () => {
    setStage(STAGES.TOPIC_SELECT);
    setTopic(null);
    setImagePreview(null);
    setBriefing(null);
    setErrorMsg('');
  };

  const selectTopic = (key) => {
    setTopic(key);
    setStage(STAGES.INTAKE);
  };

  // Traffic ticket photo path — uses structured lookup data
  const handleTicketPhoto = async (file) => {
    if (!file) return;
    setImagePreview(URL.createObjectURL(file));
    setStage(STAGES.PROCESSING);
    setErrorMsg('');

    try {
      const base64 = await fileToBase64(file);
      const countryList = Object.keys(TOPICS.traffic.countries).map(c =>
        `${c}: ${Object.keys(TOPICS.traffic.countries[c].violations).join(', ')}`
      ).join(' | ');

      const response = await fetch("/.netlify/functions/claude", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          messages: [{
            role: "user",
            content: [
              { type: "image", source: { type: "base64", media_type: file.type || "image/jpeg", data: base64 } },
              { type: "text", text: `Look at this traffic ticket/citation/challan image. Identify: 1) country (exactly one of: US, IN, UK, or "UNKNOWN"), 2) violation type matching one of these keys per country: ${countryList} (or "unknown"), 3) fine amount visible (number or null), 4) deadline date visible (string or null).
Respond ONLY with raw JSON: {"country": "US", "violationKey": "speeding", "fineOnDocument": 150, "deadlineOnDocument": "2026-07-15"}
If not a traffic ticket, set country to "UNKNOWN".` }
            ]
          }]
        })
      });

      const data = await response.json();
      const textBlock = data.content?.find(b => b.type === 'text');
      if (!textBlock) throw new Error('No response');
      const parsed = JSON.parse(textBlock.text.replace(/```json|```/g, '').trim());

      if (parsed.country === 'UNKNOWN' || !TOPICS.traffic.countries[parsed.country]) {
        setErrorMsg("This doesn't look like a traffic ticket we recognize. Try a clearer photo, or use 'Something Else' to describe your situation instead.");
        setStage(STAGES.ERROR);
        return;
      }
      const violationInfo = TOPICS.traffic.countries[parsed.country].violations[parsed.violationKey];
      if (!violationInfo) {
        setErrorMsg("We identified the country but not the specific violation type yet. Try describing it instead.");
        setStage(STAGES.ERROR);
        return;
      }

      setBriefing({
        type: 'structured',
        topic: 'traffic',
        countryData: TOPICS.traffic.countries[parsed.country],
        violationInfo,
        fineOnDocument: parsed.fineOnDocument,
        deadlineOnDocument: parsed.deadlineOnDocument,
        summaryForChat: `Traffic ticket: ${violationInfo.name} in ${TOPICS.traffic.countries[parsed.country].label}. Fine: ${TOPICS.traffic.countries[parsed.country].symbol}${violationInfo.fineRange[0]}-${violationInfo.fineRange[1]}. Points: ${violationInfo.points}. Deadline: ${violationInfo.deadline}. Contest process: ${violationInfo.howToContest}.`
      });
      setStage(STAGES.RESULT);
    } catch (err) {
      console.error(err);
      setErrorMsg("Something went wrong reading that image. Please try again.");
      setStage(STAGES.ERROR);
    }
  };

  // Free-text description path — used for every non-traffic topic, and traffic fallback
  const handleDescribe = async (description, photoFile) => {
    setStage(STAGES.PROCESSING);
    setErrorMsg('');

    try {
      let imageBlock = null;
      if (photoFile) {
        setImagePreview(URL.createObjectURL(photoFile));
        const base64 = await fileToBase64(photoFile);
        imageBlock = { type: "image", source: { type: "base64", media_type: photoFile.type || "image/jpeg", data: base64 } };
      }

      const topicLabel = TOPICS[topic].label;
      const content = [
        ...(imageBlock ? [imageBlock] : []),
        { type: "text", text: `A user is seeking help understanding a "${topicLabel}" legal situation. Here is what they wrote: "${description}"${imageBlock ? ' (a relevant photo/document is attached — read and incorporate it)' : ''}.

Generate a structured briefing. Respond ONLY with raw JSON, no markdown, in this exact shape:
{
  "headline": "A short 4-8 word title for their situation",
  "situationSummary": "1-2 sentence plain-language summary of what's going on",
  "keyFacts": ["3-5 short bullet facts relevant to their situation — typical timelines, typical amounts, what rights generally apply"],
  "options": "2-4 sentences walking through the realistic options someone in this situation has, with a genuine recommendation on the strongest path and why",
  "urgency": "low" | "medium" | "high",
  "urgencyNote": "1 sentence on timing — is there a deadline-sensitive element here"
}

Be specific and substantive — like a real, thorough consultation — while being honest that exact local statutes/court names vary by jurisdiction.` }
      ];

      const response = await fetch("/.netlify/functions/claude", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1200,
          messages: [{ role: "user", content }]
        })
      });

      const data = await response.json();
      const textBlock = data.content?.find(b => b.type === 'text');
      if (!textBlock) throw new Error('No response');
      const parsed = JSON.parse(textBlock.text.replace(/```json|```/g, '').trim());

      setBriefing({
        type: 'freeform',
        topic,
        ...parsed,
        summaryForChat: `Topic: ${topicLabel}. User's situation: "${description}". Briefing generated: ${parsed.situationSummary} Key facts: ${parsed.keyFacts.join('; ')}. Options discussed: ${parsed.options}`
      });
      setStage(STAGES.RESULT);
    } catch (err) {
      console.error(err);
      setErrorMsg("Something went wrong processing that. Please try rephrasing or try again.");
      setStage(STAGES.ERROR);
    }
  };

  // Multi-document contract review path — analyzes 1-5 documents, produces structured memo
  const handleDocumentReview = async (files, focusNote) => {
    setStage(STAGES.PROCESSING);
    setErrorMsg('');

    try {
      const imageBlocks = [];
      for (const file of files) {
        const base64 = await fileToBase64(file);
        imageBlocks.push({ type: "image", source: { type: "base64", media_type: file.type || "image/jpeg", data: base64 } });
      }
      setImagePreview(files[0] ? URL.createObjectURL(files[0]) : null);

      const content = [
        ...imageBlocks,
        { type: "text", text: `You are reviewing ${files.length} document(s) for a non-lawyer who needs to understand them before signing or responding. ${focusNote ? `They specifically want you to focus on: "${focusNote}"` : "No specific focus given — do a general review."}

Read every document carefully. Respond ONLY with raw JSON, no markdown, in this exact shape:
{
  "documentTitle": "A short descriptive title for what this document/set is (e.g. 'Freelance Services Agreement')",
  "overallRisk": "low" | "medium" | "high",
  "executiveSummary": "2-3 sentence plain-language summary of what this document is and the overall picture",
  "clauses": [
    {
      "clauseName": "Short name of the clause/section (e.g. 'Non-compete', 'Payment terms', 'Termination')",
      "whatItSays": "Plain-language explanation of what this clause actually means",
      "concernLevel": "none" | "watch" | "concern",
      "concernNote": "If watch or concern: explain why, and what a more favorable version might say. If none: brief note on why it's standard/fine."
    }
  ],
  "missingProtections": ["List of things a document like this would typically include but this one is missing or weak on, if any"],
  "recommendation": "3-5 sentence genuine recommendation: sign as-is, negotiate specific points, or seek further review — and exactly why"
}

Identify 4-8 of the most important clauses. Be specific and substantive, like a real document review — not generic boilerplate.` }
      ];

      const response = await fetch("/.netlify/functions/claude", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 2500,
          messages: [{ role: "user", content }]
        })
      });

      const data = await response.json();
      const textBlock = data.content?.find(b => b.type === 'text');
      if (!textBlock) throw new Error('No response');
      const parsed = JSON.parse(textBlock.text.replace(/```json|```/g, '').trim());

      setBriefing({
        type: 'document_review',
        topic: 'contract',
        ...parsed,
        fileCount: files.length,
        summaryForChat: `Document review of "${parsed.documentTitle}" (${files.length} document(s)). Overall risk: ${parsed.overallRisk}. Summary: ${parsed.executiveSummary} Clauses reviewed: ${parsed.clauses.map(c => `${c.clauseName} (${c.concernLevel})`).join(', ')}. Recommendation: ${parsed.recommendation}`
      });
      setStage(STAGES.RESULT);
    } catch (err) {
      console.error(err);
      setErrorMsg("Something went wrong analyzing those documents. Try clearer photos/scans, or fewer documents at once.");
      setStage(STAGES.ERROR);
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.bgTexture} />
      <header style={styles.header}>
        {stage !== STAGES.TOPIC_SELECT && (
          <button style={styles.backBtn} onClick={reset}><ArrowLeft size={18} /></button>
        )}
        <div style={styles.logoMark}><Scale size={18} strokeWidth={2.5} color="#FAF7F0" /></div>
        <span style={styles.logoText}>LexAid</span>
      </header>

      <main style={styles.main}>
        {stage === STAGES.TOPIC_SELECT && <TopicSelect onSelect={selectTopic} />}
        {stage === STAGES.INTAKE && (
          <IntakeStage
            topic={topic}
            onTicketPhoto={handleTicketPhoto}
            onDescribe={handleDescribe}
            onDocumentReview={handleDocumentReview}
            fileInputRef={fileInputRef}
          />
        )}
        {stage === STAGES.PROCESSING && <ProcessingStage imagePreview={imagePreview} />}
        {stage === STAGES.ERROR && <ErrorStage message={errorMsg} onRetry={() => setStage(STAGES.INTAKE)} />}
        {stage === STAGES.RESULT && briefing && <ResultStage briefing={briefing} onReset={reset} />}
      </main>

      <footer style={styles.footer}>
        Covers traffic, housing, workplace, consumer & contract topics · Information and guidance, not a substitute for a licensed attorney
      </footer>
    </div>
  );
}

function TopicSelect({ onSelect }) {
  return (
    <div style={styles.topicWrap}>
      <p style={styles.eyebrow}>WHAT'S GOING ON?</p>
      <h1 style={styles.heroTitle}>Get clear on your<br />situation in minutes.</h1>
      <p style={styles.heroSub}>Pick what this is about. We'll walk you through your rights, your options, and what to do next.</p>

      <div style={styles.topicGrid}>
        {Object.entries(TOPICS).map(([key, t]) => {
          const Icon = t.icon;
          return (
            <button key={key} style={styles.topicCard} onClick={() => onSelect(key)}>
              <div style={styles.topicIconWrap}><Icon size={22} color="#1B2838" strokeWidth={1.75} /></div>
              <div style={styles.topicCardTitle}>{t.label}</div>
              <div style={styles.topicCardBlurb}>{t.blurb}</div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function IntakeStage({ topic, onTicketPhoto, onDescribe, onDocumentReview, fileInputRef }) {
  const [description, setDescription] = useState('');
  const [photoFile, setPhotoFile] = useState(null);
  const [dragging, setDragging] = useState(false);
  const [docFiles, setDocFiles] = useState([]);
  const [focusNote, setFocusNote] = useState('');
  const t = TOPICS[topic];

  if (t.intakeMode === 'document_review') {
    const addFiles = (fileList) => {
      const newFiles = Array.from(fileList).slice(0, 5 - docFiles.length);
      setDocFiles(prev => [...prev, ...newFiles].slice(0, 5));
    };
    return (
      <div style={styles.intakeWrap}>
        <p style={styles.eyebrow}>{t.label.toUpperCase()}</p>
        <h2 style={styles.intakeTitle}>Upload your document(s)</h2>
        <p style={styles.intakeSub}>Photos or scans of contracts, agreements, or terms — up to 5 documents. We'll review every clause.</p>

        <div
          style={{ ...styles.dropzone, ...(dragging ? styles.dropzoneActive : {}), padding: docFiles.length ? '20px' : '40px 24px' }}
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => { e.preventDefault(); setDragging(false); addFiles(e.dataTransfer.files); }}
          onClick={() => docFiles.length < 5 && fileInputRef.current?.click()}
        >
          <input ref={fileInputRef} type="file" accept="image/*" multiple style={{ display: 'none' }} onChange={(e) => addFiles(e.target.files)} />
          {docFiles.length === 0 ? (
            <>
              <div style={styles.dropzoneIcon}><FileStack size={28} color="#1B2838" strokeWidth={1.75} /></div>
              <p style={styles.dropzoneTitle}>Add documents</p>
              <p style={styles.dropzoneSub}>JPG, PNG · Each page as a separate photo works well</p>
              <div style={styles.dropzoneBtn}><Upload size={16} /><span>Choose files</span></div>
            </>
          ) : (
            <div style={styles.fileList}>
              {docFiles.map((f, i) => (
                <div key={i} style={styles.fileListItem}>
                  <FileText size={14} color="#64748B" />
                  <span style={styles.fileListName}>{f.name}</span>
                  <button style={styles.fileListRemove} onClick={(e) => { e.stopPropagation(); setDocFiles(prev => prev.filter((_, idx) => idx !== i)); }}>
                    <Trash2 size={13} />
                  </button>
                </div>
              ))}
              {docFiles.length < 5 && (
                <div style={styles.fileListAddMore}><Upload size={13} /> Add another ({docFiles.length}/5)</div>
              )}
            </div>
          )}
        </div>

        <textarea
          style={{ ...styles.textarea, marginTop: 16 }}
          placeholder="Anything specific you're worried about? (optional) e.g. 'Check the non-compete and payment terms especially'"
          value={focusNote}
          onChange={(e) => setFocusNote(e.target.value)}
          rows={2}
        />

        <button
          style={{ ...styles.primaryBtn, ...(docFiles.length === 0 ? styles.primaryBtnDisabled : {}) }}
          disabled={docFiles.length === 0}
          onClick={() => onDocumentReview(docFiles, focusNote)}
        >
          Analyze {docFiles.length > 0 ? `${docFiles.length} document${docFiles.length > 1 ? 's' : ''}` : ''} <ChevronRight size={16} />
        </button>
      </div>
    );
  }

  if (t.intakeMode === 'photo') {
    return (
      <div style={styles.intakeWrap}>
        <p style={styles.eyebrow}>{t.label.toUpperCase()}</p>
        <h2 style={styles.intakeTitle}>Upload a photo of your ticket</h2>
        <div
          style={{ ...styles.dropzone, ...(dragging ? styles.dropzoneActive : {}) }}
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => { e.preventDefault(); setDragging(false); const f = e.dataTransfer.files?.[0]; if (f) onTicketPhoto(f); }}
          onClick={() => fileInputRef.current?.click()}
        >
          <input ref={fileInputRef} type="file" accept="image/*" capture="environment" style={{ display: 'none' }} onChange={(e) => onTicketPhoto(e.target.files?.[0])} />
          <div style={styles.dropzoneIcon}><Camera size={28} color="#1B2838" strokeWidth={1.75} /></div>
          <p style={styles.dropzoneTitle}>Take or upload a photo</p>
          <p style={styles.dropzoneSub}>We don't store your image after analysis</p>
          <div style={styles.dropzoneBtn}><Upload size={16} /><span>Choose photo</span></div>
        </div>
        <button style={styles.linkBtn} onClick={() => onDescribe("I have a traffic ticket but want to describe it instead of uploading a photo.", null)}>
          Prefer to just describe it instead? →
        </button>
      </div>
    );
  }

  const allowPhoto = t.intakeMode === 'describe_or_photo';

  return (
    <div style={styles.intakeWrap}>
      <p style={styles.eyebrow}>{t.label.toUpperCase()}</p>
      <h2 style={styles.intakeTitle}>Tell us what's happening</h2>
      <p style={styles.intakeSub}>Write it in your own words — as much detail as you have. Dates, amounts, and what's already happened all help.</p>
      <textarea
        style={styles.textarea}
        placeholder={topicPlaceholder(topic)}
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        rows={6}
      />
      {allowPhoto && (
        <div style={styles.photoAttach}>
          <input ref={fileInputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={(e) => setPhotoFile(e.target.files?.[0])} />
          <button style={styles.attachBtn} onClick={() => fileInputRef.current?.click()}>
            <Upload size={14} /> {photoFile ? photoFile.name : 'Attach a document or photo (optional)'}
          </button>
        </div>
      )}
      <button
        style={{ ...styles.primaryBtn, ...(description.trim().length < 8 ? styles.primaryBtnDisabled : {}) }}
        disabled={description.trim().length < 8}
        onClick={() => onDescribe(description, photoFile)}
      >
        Get my briefing <ChevronRight size={16} />
      </button>
    </div>
  );
}

function topicPlaceholder(topic) {
  const examples = {
    tenant: "e.g. My landlord won't return my security deposit, and it's been 45 days since I moved out...",
    employment: "e.g. I was fired yesterday after reporting a safety issue last week. I worked there for 2 years...",
    consumer: "e.g. I ordered a laptop online, it arrived broken, and the company is refusing a refund...",
    contract: "e.g. I'm about to sign a freelance contract and there's a clause about IP ownership I don't understand...",
    other: "e.g. Describe your situation in as much detail as you can..."
  };
  return examples[topic] || examples.other;
}

function ProcessingStage({ imagePreview }) {
  return (
    <div style={styles.processingWrap}>
      {imagePreview && (
        <div style={styles.previewFrame}><img src={imagePreview} alt="preview" style={styles.previewImg} /></div>
      )}
      <div style={styles.processingStatus}>
        <Loader2 size={20} color="#D97706" style={{ animation: 'spin 1s linear infinite' }} />
        <span>Putting together your briefing…</span>
      </div>
      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

function ErrorStage({ message, onRetry }) {
  return (
    <div style={styles.errorWrap}>
      <AlertCircle size={32} color="#B45309" strokeWidth={1.75} />
      <p style={styles.errorText}>{message}</p>
      <button style={styles.primaryBtn} onClick={onRetry}>Try again</button>
    </div>
  );
}

function ResultStage({ briefing, onReset }) {
  return (
    <div style={styles.resultWrap}>
      <div style={styles.resultHeader}>
        <button style={styles.backLink} onClick={onReset}><X size={14} /> Start over</button>
        <span style={styles.countryBadge}>{TOPICS[briefing.topic].label}</span>
      </div>

      {briefing.type === 'structured' && <StructuredCard briefing={briefing} />}
      {briefing.type === 'freeform' && <FreeformCard briefing={briefing} />}
      {briefing.type === 'document_review' && <DocumentReviewCard briefing={briefing} />}

      <ChatPanel briefing={briefing} />
    </div>
  );
}

function StructuredCard({ briefing }) {
  const { violationInfo, countryData, fineOnDocument, deadlineOnDocument } = briefing;
  const [lo, hi] = violationInfo.fineRange;
  const fineDisplay = fineOnDocument ? `${countryData.symbol}${fineOnDocument.toLocaleString()}` : lo === hi ? `${countryData.symbol}${lo.toLocaleString()}` : `${countryData.symbol}${lo.toLocaleString()} – ${countryData.symbol}${hi.toLocaleString()}`;

  return (
    <div style={styles.docCard}>
      <div style={styles.docCardStamp}>{violationInfo.contestable ? 'CONTESTABLE' : 'STANDARD FINE'}</div>
      <h2 style={styles.docTitle}>{violationInfo.name}</h2>
      <div style={styles.statGrid}>
        <Stat icon={<DollarSign size={16} />} label="Fine amount" value={fineDisplay} accent />
        <Stat icon={<Clock size={16} />} label="Deadline" value={deadlineOnDocument || violationInfo.deadline} />
      </div>
      <Section title="Points & license impact" icon={<AlertCircle size={16} />}>{violationInfo.points}</Section>
      <Section title="Insurance impact" icon={<FileText size={16} />}>{violationInfo.impact}</Section>
      <Section title={violationInfo.contestable ? "How to contest this" : "Your options"} icon={<CheckCircle2 size={16} />} highlight>{violationInfo.howToContest}</Section>
      <p style={styles.disclaimer}>{countryData.notes} This is general information, not legal advice specific to your situation.</p>
    </div>
  );
}

function FreeformCard({ briefing }) {
  const urgencyColor = { low: '#15803D', medium: '#D97706', high: '#B91C1C' }[briefing.urgency] || '#64748B';
  const urgencyLabel = { low: 'LOW URGENCY', medium: 'TIME-SENSITIVE', high: 'ACT SOON' }[briefing.urgency] || '';

  return (
    <div style={styles.docCard}>
      <div style={{ ...styles.docCardStamp, color: urgencyColor, borderColor: urgencyColor }}>{urgencyLabel}</div>
      <h2 style={styles.docTitle}>{briefing.headline}</h2>
      <p style={styles.situationText}>{briefing.situationSummary}</p>

      <Section title="Key facts" icon={<FileText size={16} />}>
        <ul style={styles.factList}>
          {briefing.keyFacts?.map((f, i) => <li key={i} style={styles.factItem}>{f}</li>)}
        </ul>
      </Section>

      <Section title="Your options" icon={<CheckCircle2 size={16} />} highlight>{briefing.options}</Section>

      {briefing.urgencyNote && (
        <Section title="Timing" icon={<Clock size={16} />}>{briefing.urgencyNote}</Section>
      )}

      <p style={styles.disclaimer}>This is general guidance based on what you've described — not legal advice specific to your full circumstances. For high-stakes or contested matters, a local attorney can represent your interests directly.</p>
    </div>
  );
}

function DocumentReviewCard({ briefing }) {
  const riskColor = { low: '#15803D', medium: '#D97706', high: '#B91C1C' }[briefing.overallRisk] || '#64748B';
  const riskLabel = { low: 'LOW RISK', medium: 'MODERATE RISK', high: 'HIGH RISK' }[briefing.overallRisk] || '';
  const concernColor = { none: '#15803D', watch: '#D97706', concern: '#B91C1C' };
  const concernLabel = { none: 'Standard', watch: 'Watch', concern: 'Concern' };

  return (
    <div style={styles.docCard}>
      <div style={{ ...styles.docCardStamp, color: riskColor, borderColor: riskColor }}>{riskLabel}</div>
      <h2 style={styles.docTitle}>{briefing.documentTitle}</h2>
      <p style={styles.situationText}>{briefing.executiveSummary}</p>
      <p style={styles.fileCountNote}>{briefing.fileCount} document{briefing.fileCount > 1 ? 's' : ''} reviewed</p>

      <div style={styles.clauseList}>
        {briefing.clauses?.map((c, i) => (
          <div key={i} style={styles.clauseItem}>
            <div style={styles.clauseHeader}>
              <span style={styles.clauseName}>{c.clauseName}</span>
              <span style={{ ...styles.clauseBadge, color: concernColor[c.concernLevel] || '#64748B', borderColor: concernColor[c.concernLevel] || '#64748B' }}>
                {concernLabel[c.concernLevel] || c.concernLevel}
              </span>
            </div>
            <p style={styles.clauseText}>{c.whatItSays}</p>
            {c.concernNote && <p style={styles.clauseNote}>{c.concernNote}</p>}
          </div>
        ))}
      </div>

      {briefing.missingProtections?.length > 0 && (
        <Section title="Worth adding" icon={<AlertCircle size={16} />}>
          <ul style={styles.factList}>
            {briefing.missingProtections.map((m, i) => <li key={i} style={styles.factItem}>{m}</li>)}
          </ul>
        </Section>
      )}

      <Section title="Recommendation" icon={<CheckCircle2 size={16} />} highlight>{briefing.recommendation}</Section>

      <p style={styles.disclaimer}>This is a general document review based on what was uploaded — not legal advice on whether to sign. For high-value or high-stakes agreements, a local attorney can review the final version directly.</p>
    </div>
  );
}
function Stat({ icon, label, value, accent }) {
  return (
    <div style={styles.statBox}>
      <div style={{ ...styles.statIcon, color: accent ? '#D97706' : '#64748B' }}>{icon}</div>
      <div>
        <div style={styles.statLabel}>{label}</div>
        <div style={{ ...styles.statValue, color: accent ? '#B45309' : '#1B2838' }}>{value}</div>
      </div>
    </div>
  );
}

function Section({ title, icon, children, highlight }) {
  return (
    <div style={{ ...styles.section, ...(highlight ? styles.sectionHighlight : {}) }}>
      <div style={styles.sectionTitle}>
        <span style={{ color: highlight ? '#15803D' : '#64748B' }}>{icon}</span>
        {title}
      </div>
      <div style={styles.sectionText}>{children}</div>
    </div>
  );
}

function ChatPanel({ briefing }) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [language, setLanguage] = useState('English');
  const scrollRef = useRef(null);

  const systemContext = `You are the expert knowledge engine inside LexAid, an app that helps people understand and respond to everyday legal situations — traffic tickets, housing/tenant issues, workplace disputes, consumer disputes, and contract questions. You have the depth of someone who has spent decades studying law, court procedure, and the practical playbook people actually use across the US, India, and UK, and general knowledge of how these systems work globally.

THEIR SITUATION (ground truth — generated from what they told the app):
${briefing.summaryForChat}

HOW TO ANSWER:
- Be thorough and specific. Walk through the actual reasoning a knowledgeable person would use: what factors matter, what the tradeoffs are, what most people in this situation do, and why.
- Explain real mechanics — how the relevant process actually works, what evidence helps, what timelines matter, what happens if someone misses a deadline or takes no action.
- When asked "what should I do," give a genuine, opinionated, well-reasoned answer — lay out the strongest option and why, like a knowledgeable friend who happens to know this field well.
- Speak with authority on general law, process, and strategy. Be exact and confident about things that are generally true.
- Be honest about the one real limit: exact statute numbers, exact court/agency names, exact local fees and deadlines vary by specific city/county/state/country and change over time. When a question needs that hyper-local precision, say so plainly and tell them where to get it (the agency/landlord/employer named in their situation, their local court, or a local attorney) — but don't let that limit make the rest of your answer timid.
- You are not this person's attorney and this isn't a substitute for representation in a contested legal proceeding — but you are a genuine expert resource, not a disclaimer machine. Mention the attorney/representation option naturally when stakes are high (termination from employment, eviction, large sums, contested hearings) — not as a reflexive caveat on every message.
- If asked to draft something (a letter, an email, a response), draft it fully and well — a real, usable first draft, not a vague outline.
- Keep responses focused and readable — usually 3-8 sentences, longer when the question genuinely calls for a deeper walkthrough or drafted document.
- Never invent a specific statute number, case citation, or court name you're not confident is accurate — speak in accurate general terms instead when precision isn't possible.

LANGUAGE: Respond entirely in ${language}, regardless of what language the question is asked in, unless asked to switch. Use natural, fluent, native-quality ${language}.`;

  const sendMessage = async () => {
    const text = input.trim();
    if (!text || loading) return;
    const newMessages = [...messages, { role: 'user', content: text }];
    setMessages(newMessages);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch("/.netlify/functions/claude", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 800,
          system: systemContext,
          messages: newMessages.map(m => ({ role: m.role, content: m.content }))
        })
      });
      const data = await response.json();
      const textBlock = data.content?.find(b => b.type === 'text');
      const reply = textBlock?.text || "I couldn't generate a response — try asking again.";
      setMessages(prev => [...prev, { role: 'assistant', content: reply }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'assistant', content: "Something went wrong reaching the assistant. Please try again." }]);
    } finally {
      setLoading(false);
      setTimeout(() => scrollRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    }
  };

  if (!open) {
    return (
      <button style={styles.secondaryAction} onClick={() => setOpen(true)}>
        <MessageCircle size={16} /> Ask a follow-up question
      </button>
    );
  }

  return (
    <div style={styles.chatCard}>
      <div style={styles.chatHeader}>
        <div style={styles.chatHeaderLeft}><MessageCircle size={16} color="#1B2838" /><span style={styles.chatHeaderTitle}>Ask LexAid</span></div>
        <div style={styles.chatHeaderRight}>
          <select style={styles.languageSelect} value={language} onChange={(e) => setLanguage(e.target.value)}>
            {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
          </select>
          <button style={styles.chatClose} onClick={() => setOpen(false)}><X size={16} /></button>
        </div>
      </div>
      <div style={styles.chatBody}>
        {messages.length === 0 && (
          <div style={styles.chatEmpty}>
            <p style={styles.chatEmptyText}>Ask anything about your situation — for example:</p>
            <div style={styles.chatSuggestions}>
              {["What's the strongest option here?", "Can you draft a response for me?", "What happens if I do nothing?"].map((s, i) => (
                <button key={i} style={styles.chatSuggestionBtn} onClick={() => setInput(s)}>{s}</button>
              ))}
            </div>
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} style={{ ...styles.chatBubbleRow, justifyContent: m.role === 'user' ? 'flex-end' : 'flex-start' }}>
            <div style={m.role === 'user' ? styles.chatBubbleUser : styles.chatBubbleAssistant}>{m.content}</div>
          </div>
        ))}
        {loading && <div style={styles.chatBubbleRow}><div style={styles.chatBubbleAssistant}><Loader2 size={14} style={{ animation: 'spin 1s linear infinite', display: 'inline-block' }} /></div></div>}
        <div ref={scrollRef} />
      </div>
      <div style={styles.chatInputRow}>
        <input style={styles.chatInput} placeholder="Type your question…" value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') sendMessage(); }} />
        <button style={styles.chatSendBtn} onClick={sendMessage} disabled={loading}><Send size={16} /></button>
      </div>
      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

const styles = {
  page: { minHeight: '100vh', background: '#FAF7F0', fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif", position: 'relative', display: 'flex', flexDirection: 'column' },
  bgTexture: { position: 'fixed', inset: 0, backgroundImage: 'radial-gradient(circle at 1px 1px, #1B283808 1px, transparent 1px)', backgroundSize: '24px 24px', pointerEvents: 'none' },
  header: { display: 'flex', alignItems: 'center', gap: 10, padding: '20px 24px', position: 'relative', zIndex: 1 },
  backBtn: { background: 'none', border: 'none', cursor: 'pointer', color: '#64748B', padding: 4, display: 'flex', marginRight: 2 },
  logoMark: { width: 32, height: 32, background: '#1B2838', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center' },
  logoText: { fontFamily: "'Georgia', serif", fontSize: 19, fontWeight: 600, color: '#1B2838', letterSpacing: '-0.01em' },
  main: { flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '24px 20px 60px', position: 'relative', zIndex: 1, maxWidth: 560, margin: '0 auto', width: '100%', boxSizing: 'border-box' },
  footer: { textAlign: 'center', fontSize: 12, color: '#94A3B8', padding: '16px 20px 24px', position: 'relative', zIndex: 1 },

  topicWrap: { width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', paddingTop: 12 },
  eyebrow: { fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', color: '#D97706', marginBottom: 14 },
  heroTitle: { fontFamily: "'Georgia', serif", fontSize: 32, lineHeight: 1.15, color: '#1B2838', margin: '0 0 14px', fontWeight: 600, letterSpacing: '-0.02em' },
  heroSub: { fontSize: 15.5, lineHeight: 1.6, color: '#475569', maxWidth: 440, margin: '0 0 32px' },

  topicGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, width: '100%' },
  topicCard: { background: '#FFFFFF', border: '1px solid #ECE8DC', borderRadius: 14, padding: '20px 16px', textAlign: 'left', cursor: 'pointer', display: 'flex', flexDirection: 'column', gap: 4 },
  topicIconWrap: { width: 40, height: 40, borderRadius: 10, background: '#F1EFE6', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  topicCardTitle: { fontSize: 14.5, fontWeight: 700, color: '#1B2838' },
  topicCardBlurb: { fontSize: 12, color: '#94A3B8', lineHeight: 1.4 },

  intakeWrap: { width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', paddingTop: 8 },
  intakeTitle: { fontFamily: "'Georgia', serif", fontSize: 24, color: '#1B2838', fontWeight: 600, margin: '0 0 8px' },
  intakeSub: { fontSize: 14, color: '#64748B', lineHeight: 1.5, margin: '0 0 20px', maxWidth: 420 },

  textarea: { width: '100%', border: '1px solid #ECE8DC', borderRadius: 12, padding: '16px', fontSize: 14.5, fontFamily: 'inherit', resize: 'vertical', outline: 'none', color: '#1B2838', background: '#FFFFFF', boxSizing: 'border-box', lineHeight: 1.5 },
  photoAttach: { width: '100%', marginTop: 12 },
  attachBtn: { display: 'flex', alignItems: 'center', gap: 8, background: '#FFFFFF', border: '1px dashed #CBD5C0', borderRadius: 10, padding: '10px 14px', fontSize: 13, color: '#64748B', cursor: 'pointer', width: '100%', justifyContent: 'center' },
  linkBtn: { background: 'none', border: 'none', color: '#64748B', fontSize: 13, cursor: 'pointer', marginTop: 16, textDecoration: 'underline' },

  dropzone: { width: '100%', border: '2px dashed #CBD5C0', borderRadius: 16, padding: '40px 24px', background: '#FFFFFF', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center' },
  dropzoneActive: { borderColor: '#D97706', background: '#FFFBF5' },
  dropzoneIcon: { width: 56, height: 56, borderRadius: '50%', background: '#F1EFE6', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  dropzoneTitle: { fontSize: 16, fontWeight: 600, color: '#1B2838', margin: '0 0 4px' },
  dropzoneSub: { fontSize: 13, color: '#94A3B8', margin: '0 0 20px' },
  dropzoneBtn: { display: 'flex', alignItems: 'center', gap: 8, background: '#1B2838', color: '#FAF7F0', padding: '10px 20px', borderRadius: 8, fontSize: 14, fontWeight: 600 },

  processingWrap: { width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', paddingTop: 40 },
  previewFrame: { width: 220, height: 220, borderRadius: 16, overflow: 'hidden', boxShadow: '0 12px 32px rgba(27,40,56,0.15)', marginBottom: 32, border: '4px solid white' },
  previewImg: { width: '100%', height: '100%', objectFit: 'cover' },
  processingStatus: { display: 'flex', alignItems: 'center', gap: 10, fontSize: 15, color: '#475569', fontWeight: 500 },

  errorWrap: { display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', paddingTop: 60, gap: 16, maxWidth: 360 },
  errorText: { fontSize: 15, color: '#475569', lineHeight: 1.6, margin: 0 },
  primaryBtn: { background: '#1B2838', color: '#FAF7F0', border: 'none', padding: '13px 24px', borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: 'pointer', marginTop: 8, width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 },
  primaryBtnDisabled: { opacity: 0.4, cursor: 'not-allowed' },

  resultWrap: { width: '100%' },
  resultHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  backLink: { display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', color: '#64748B', fontSize: 13, cursor: 'pointer', padding: 0, fontWeight: 500 },
  countryBadge: { fontSize: 12, fontWeight: 700, color: '#1B2838', background: '#E8E4D8', padding: '4px 10px', borderRadius: 6, letterSpacing: '0.02em' },

  docCard: { background: '#FFFFFF', borderRadius: 16, padding: 28, boxShadow: '0 1px 3px rgba(27,40,56,0.08), 0 1px 2px rgba(27,40,56,0.04)', border: '1px solid #ECE8DC', position: 'relative' },
  docCardStamp: { position: 'absolute', top: 24, right: 24, fontSize: 10, fontWeight: 700, letterSpacing: '0.1em', color: '#15803D', border: '1.5px solid #15803D', borderRadius: 4, padding: '3px 8px', transform: 'rotate(3deg)' },
  docTitle: { fontFamily: "'Georgia', serif", fontSize: 24, color: '#1B2838', margin: '0 0 12px', fontWeight: 600, paddingRight: 110 },
  situationText: { fontSize: 14.5, color: '#475569', lineHeight: 1.6, margin: '0 0 20px' },

  statGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 24 },
  statBox: { display: 'flex', gap: 10, alignItems: 'flex-start', background: '#FAF7F0', padding: '12px 14px', borderRadius: 10 },
  statIcon: { marginTop: 2 },
  statLabel: { fontSize: 11, color: '#94A3B8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 2 },
  statValue: { fontSize: 17, fontWeight: 700 },

  section: { borderTop: '1px solid #F1EFE6', padding: '16px 0' },
  sectionHighlight: { background: '#F7FAF5', margin: '8px -28px -8px', padding: '16px 28px 24px', borderTop: 'none', borderRadius: '0 0 16px 16px' },
  sectionTitle: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, fontWeight: 700, color: '#1B2838', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.03em' },
  sectionText: { fontSize: 14.5, lineHeight: 1.65, color: '#475569', margin: 0 },
  factList: { margin: 0, paddingLeft: 18, display: 'flex', flexDirection: 'column', gap: 6 },
  factItem: { fontSize: 14, lineHeight: 1.5, color: '#475569' },

  disclaimer: { fontSize: 12, color: '#94A3B8', lineHeight: 1.5, marginTop: 20, paddingTop: 16, borderTop: '1px solid #F1EFE6' },

  fileList: { width: '100%', display: 'flex', flexDirection: 'column', gap: 8 },
  fileListItem: { display: 'flex', alignItems: 'center', gap: 8, background: '#FAF7F0', borderRadius: 8, padding: '8px 10px' },
  fileListName: { flex: 1, fontSize: 13, color: '#1B2838', textAlign: 'left', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  fileListRemove: { background: 'none', border: 'none', cursor: 'pointer', color: '#94A3B8', display: 'flex', padding: 4 },
  fileListAddMore: { display: 'flex', alignItems: 'center', gap: 6, justifyContent: 'center', fontSize: 12.5, color: '#64748B', padding: '8px', border: '1px dashed #CBD5C0', borderRadius: 8, cursor: 'pointer' },

  fileCountNote: { fontSize: 12, color: '#94A3B8', margin: '-12px 0 16px' },
  clauseList: { display: 'flex', flexDirection: 'column', gap: 14, borderTop: '1px solid #F1EFE6', paddingTop: 16 },
  clauseItem: { paddingBottom: 14, borderBottom: '1px solid #F8F6EF' },
  clauseHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  clauseName: { fontSize: 14.5, fontWeight: 700, color: '#1B2838' },
  clauseBadge: { fontSize: 10.5, fontWeight: 700, letterSpacing: '0.04em', border: '1.5px solid', borderRadius: 4, padding: '2px 7px', textTransform: 'uppercase' },
  clauseText: { fontSize: 13.5, lineHeight: 1.55, color: '#475569', margin: '0 0 6px' },
  clauseNote: { fontSize: 13, lineHeight: 1.55, color: '#B45309', margin: 0, fontStyle: 'italic' },

  secondaryAction: { width: '100%', marginTop: 16, background: '#FFFFFF', border: '1.5px solid #1B2838', color: '#1B2838', padding: '14px', borderRadius: 10, fontSize: 14.5, fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, cursor: 'pointer' },

  chatCard: { width: '100%', marginTop: 16, background: '#FFFFFF', borderRadius: 16, border: '1px solid #ECE8DC', boxShadow: '0 1px 3px rgba(27,40,56,0.08)', overflow: 'hidden', display: 'flex', flexDirection: 'column', maxHeight: 480 },
  chatHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 16px', borderBottom: '1px solid #F1EFE6' },
  chatHeaderLeft: { display: 'flex', alignItems: 'center', gap: 8 },
  chatHeaderTitle: { fontSize: 14, fontWeight: 700, color: '#1B2838' },
  chatHeaderRight: { display: 'flex', alignItems: 'center', gap: 8 },
  chatClose: { background: 'none', border: 'none', cursor: 'pointer', color: '#94A3B8', padding: 4, display: 'flex' },
  languageSelect: { fontSize: 12.5, color: '#475569', border: '1px solid #ECE8DC', borderRadius: 6, padding: '4px 8px', background: '#FAF7F0', cursor: 'pointer', fontFamily: 'inherit' },
  chatBody: { flex: 1, overflowY: 'auto', padding: '16px', display: 'flex', flexDirection: 'column', gap: 10, minHeight: 160 },
  chatEmpty: { display: 'flex', flexDirection: 'column', gap: 10 },
  chatEmptyText: { fontSize: 13, color: '#94A3B8', margin: '0 0 4px' },
  chatSuggestions: { display: 'flex', flexDirection: 'column', gap: 8 },
  chatSuggestionBtn: { textAlign: 'left', background: '#FAF7F0', border: '1px solid #ECE8DC', borderRadius: 8, padding: '10px 12px', fontSize: 13.5, color: '#475569', cursor: 'pointer' },
  chatBubbleRow: { display: 'flex', width: '100%' },
  chatBubbleUser: { background: '#1B2838', color: '#FAF7F0', padding: '10px 14px', borderRadius: '14px 14px 4px 14px', fontSize: 14, lineHeight: 1.5, maxWidth: '80%', whiteSpace: 'pre-wrap' },
  chatBubbleAssistant: { background: '#FAF7F0', color: '#1B2838', padding: '10px 14px', borderRadius: '14px 14px 14px 4px', fontSize: 14, lineHeight: 1.5, maxWidth: '85%', whiteSpace: 'pre-wrap' },
  chatInputRow: { display: 'flex', gap: 8, padding: '12px 16px', borderTop: '1px solid #F1EFE6' },
  chatInput: { flex: 1, border: '1px solid #ECE8DC', borderRadius: 8, padding: '10px 12px', fontSize: 14, fontFamily: 'inherit', outline: 'none' },
  chatSendBtn: { background: '#1B2838', color: '#FAF7F0', border: 'none', borderRadius: 8, width: 38, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }
};
